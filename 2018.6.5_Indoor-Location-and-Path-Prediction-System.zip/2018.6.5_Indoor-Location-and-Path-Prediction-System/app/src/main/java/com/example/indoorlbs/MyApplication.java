package com.example.indoorlbs;

import android.app.Application;

public class MyApplication  extends Application {
}
