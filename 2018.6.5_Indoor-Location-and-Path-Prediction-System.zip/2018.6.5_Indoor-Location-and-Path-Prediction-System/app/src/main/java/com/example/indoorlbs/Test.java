package com.example.indoorlbs;

public class Test {

    float x,y;

    public Test(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float getX() { return  x; }
    public float getY() { return  y; }
}
